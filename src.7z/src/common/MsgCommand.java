package common;

public enum MsgCommand {
	REQUEST,COMMIT,WITHDRAW,GRANT,WAIT,ACK
}
